(function() {
    let elementList = document.getElementsByName('meldung.newsticker.bottom.kommentarelesen');
    let comment = elementList[0];
    
    comment.style.display = 'none';
}
)();
